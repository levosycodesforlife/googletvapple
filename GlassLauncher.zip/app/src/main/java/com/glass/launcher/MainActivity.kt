package com.glass.launcher

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.tv.TvContract
import android.media.tv.TvInputInfo
import android.media.tv.TvInputManager
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.key.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

data class AppItem(val label: String, val img: ImageBitmap, val wide: Boolean, val intent: Intent)
data class Wx(val t: Int, val desc: String, val hi: Int, val lo: Int)

class MainActivity : ComponentActivity() {
    private var tick by mutableIntStateOf(0)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Home(this, tick) }
    }
    override fun onResume() { super.onResume(); tick++ }
}

// ---------- data helpers ----------
fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val out = LinkedHashMap<String, AppItem>()
    for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
        for (ri in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)) {
            val pkg = ri.activityInfo.packageName
            if (pkg == ctx.packageName || out.containsKey(pkg)) continue
            val intent = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg) ?: continue
            val banner = runCatching { ri.activityInfo.loadBanner(pm) }.getOrNull()
            val bmp = if (banner != null) banner.toBitmap(320, 180) else ri.loadIcon(pm).toBitmap(128, 128)
            out[pkg] = AppItem(ri.loadLabel(pm).toString(), bmp.asImageBitmap(), banner != null, intent)
        }
    }
    return out.values.sortedBy { it.label.lowercase() }
}

fun wmo(c: Int) = when (c) {
    0 -> "Clear"
    1, 2 -> "Partly cloudy"
    3 -> "Cloudy"
    45, 48 -> "Fog"
    in 51..67, in 80..82 -> "Rain"
    in 71..77, 85, 86 -> "Snow"
    else -> "Storm"
}

fun fetchWx(): Wx {
    val loc = JSONObject(URL("https://ipwho.is/").readText())
    val u = "https://api.open-meteo.com/v1/forecast?latitude=${loc.getDouble("latitude")}&longitude=${loc.getDouble("longitude")}" +
        "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&temperature_unit=fahrenheit&timezone=auto&forecast_days=1"
    val j = JSONObject(URL(u).readText())
    val c = j.getJSONObject("current")
    val d = j.getJSONObject("daily")
    return Wx(
        c.getDouble("temperature_2m").roundToInt(), wmo(c.getInt("weather_code")),
        d.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
        d.getJSONArray("temperature_2m_min").getDouble(0).roundToInt()
    )
}

fun hdmiInputs(ctx: Context): List<TvInputInfo> =
    (ctx.getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager).tvInputList.filter { it.type == TvInputInfo.TYPE_HDMI }

fun Context.go(i: Intent) = runCatching { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    .onFailure { Toast.makeText(this, "Can't open that on this TV", Toast.LENGTH_SHORT).show() }

// ---------- glass UI ----------
fun Modifier.glass(r: Dp = 24.dp) = clip(RoundedCornerShape(r))
    .background(Brush.verticalGradient(listOf(Color(0x59FFFFFF), Color(0x26FFFFFF))))
    .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(r))

@Composable
fun Pill(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(50)
    Box(
        modifier.clip(shape).background(if (f) Color.White else Color(0x40FFFFFF))
            .onFocusChanged { f = it.isFocused }.clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 12.dp)
    ) { Text(text, color = if (f) Color.Black else Color.White, fontSize = 18.sp) }
}

@Composable
fun Tile(a: AppItem, modifier: Modifier, onFocus: () -> Unit, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    val s by animateFloatAsState(if (f) 1.08f else 1f, label = "scale")
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier.width(190.dp).height(107.dp).scale(s).clip(shape)
            .background(Color(0x59000000))
            .then(if (f) Modifier.border(3.dp, Color.White, shape) else Modifier)
            .onFocusChanged { f = it.isFocused; if (it.isFocused) onFocus() }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        if (a.wide) Image(a.img, a.label, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Image(a.img, null, Modifier.size(52.dp))
            Text(a.label, color = Color.White, fontSize = 13.sp, maxLines = 1)
        }
    }
}

@Composable
fun Dock(apps: List<AppItem>, onFocus: (String) -> Unit, open: (AppItem) -> Unit) {
    val first = remember { FocusRequester() }
    LaunchedEffect(apps.isNotEmpty()) { if (apps.isNotEmpty()) { delay(150); runCatching { first.requestFocus() } } }
    LazyRow(
        Modifier.padding(horizontal = 32.dp).fillMaxWidth().glass(30.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        itemsIndexed(apps) { i, a ->
            Tile(a, if (i == 0) Modifier.focusRequester(first) else Modifier, { onFocus(a.label) }) { open(a) }
        }
    }
}

@Composable
fun VolumeBar(am: AudioManager) {
    val max = remember { am.getStreamMaxVolume(AudioManager.STREAM_MUSIC) }
    var v by remember { mutableIntStateOf(am.getStreamVolume(AudioManager.STREAM_MUSIC)) }
    var f by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(50))
            .background(if (f) Color(0x80FFFFFF) else Color(0x40FFFFFF))
            .onFocusChanged { f = it.isFocused }
            .onKeyEvent { e ->
                if (e.type == KeyEventType.KeyDown && (e.key == Key.DirectionLeft || e.key == Key.DirectionRight)) {
                    am.adjustStreamVolume(
                        AudioManager.STREAM_MUSIC,
                        if (e.key == Key.DirectionRight) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0
                    )
                    v = am.getStreamVolume(AudioManager.STREAM_MUSIC)
                    true
                } else false
            }
            .focusable()
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (v == 0) "🔇" else "🔊", color = Color.White, fontSize = 18.sp)
        Spacer(Modifier.width(12.dp))
        Box(Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(50)).background(Color(0x40FFFFFF))) {
            Box(Modifier.fillMaxWidth(if (max > 0) v / max.toFloat() else 0f).fillMaxHeight().background(Color.White))
        }
        Spacer(Modifier.width(12.dp))
        Text("$v", color = Color.White, fontSize = 16.sp)
    }
}

@Composable
fun Panel(ctx: Context) {
    val am = remember { ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val hdmi = remember { runCatching { hdmiInputs(ctx) }.getOrDefault(emptyList()) }
    val w = Modifier.fillMaxWidth()
    Column(Modifier.width(340.dp).glass(28.dp).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Pill("🌙  Screensaver", w) { ctx.go(Intent().setClassName("com.android.systemui", "com.android.systemui.Somnambulator")) }
        Pill("🔵  Bluetooth", w) { ctx.go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) }
        Pill("🎧  Sound", w) { ctx.go(Intent(Settings.ACTION_SOUND_SETTINGS)) }
        Pill("⚙️  Settings", w) { ctx.go(Intent(Settings.ACTION_SETTINGS)) }
        VolumeBar(am)
        if (hdmi.isNotEmpty()) {
            Text("SOURCES", color = Color(0xAAFFFFFF), fontSize = 13.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 8.dp, top = 6.dp))
            hdmi.forEach { t ->
                Pill("🔌  " + (t.loadCustomLabel(ctx) ?: t.loadLabel(ctx)), w) {
                    ctx.go(Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(t.id)))
                }
            }
        }
    }
}

@Composable
fun Home(ctx: Context, tick: Int) {
    val apps by produceState(emptyList<AppItem>(), tick) { value = withContext(Dispatchers.Default) { loadApps(ctx) } }
    var panel by remember { mutableStateOf(false) }
    var focused by remember { mutableStateOf("") }
    var now by remember { mutableStateOf(Date()) }
    var wx by remember { mutableStateOf<Wx?>(null) }
    BackHandler { panel = false }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000L * (60 - System.currentTimeMillis() / 1000 % 60)) } }
    LaunchedEffect(Unit) {
        while (true) {
            val r = withContext(Dispatchers.IO) { runCatching { fetchWx() }.getOrNull() }
            if (r != null) wx = r
            delay(if (r != null) 1_800_000L else 60_000L)
        }
    }
    // Drop your photo at app/src/main/res/drawable-nodpi/wallpaper.jpg to use it as the background
    val wid = remember { ctx.resources.getIdentifier("wallpaper", "drawable", ctx.packageName) }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1B3A4B), Color(0xFF0B1F14))))) {
        if (wid != 0) Image(painterResource(wid), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)

        wx?.let { w ->
            Column(Modifier.align(Alignment.TopStart).padding(32.dp).glass().padding(horizontal = 24.dp, vertical = 14.dp)) {
                Text("${w.t}°", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.Medium)
                Text("${w.desc} · H ${w.hi}° L ${w.lo}°", color = Color(0xCCFFFFFF), fontSize = 16.sp)
            }
        }

        Column(
            Modifier.align(Alignment.TopEnd).padding(32.dp),
            horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.glass(50.dp).padding(horizontal = 28.dp, vertical = 12.dp)) {
                    Text(SimpleDateFormat("h:mm", Locale.getDefault()).format(now), color = Color.White, fontSize = 28.sp)
                }
                Pill("🎛") { panel = !panel }
            }
            if (panel) Panel(ctx)
        }

        Column(Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            if (focused.isNotEmpty()) Box(Modifier.glass(50.dp).padding(horizontal = 18.dp, vertical = 6.dp)) {
                Text(focused, color = Color.White, fontSize = 16.sp)
            }
            Spacer(Modifier.height(10.dp))
            Dock(apps, { focused = it }) { ctx.go(it.intent) }
        }
    }
}
